import { LoginService } from './_service/login.service';
import { MenuService } from './_service/menu.service';
import { Menu } from './_model/menu';
import { Component, OnInit } from '@angular/core';
import { Rol } from './_model/rol';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  menus: Menu[] = [];
  roles: Rol[] = []; // DES
  public usuarioData; // DES
  constructor(
    private menuService: MenuService,
    public loginService: LoginService
  ) {}

  ngOnInit() {
    this.menuService.getMenuCambio().subscribe((data) => (this.menus = data));

    // DES
    this.usuarioData = this.loginService.getDatosToken();
  }
}
