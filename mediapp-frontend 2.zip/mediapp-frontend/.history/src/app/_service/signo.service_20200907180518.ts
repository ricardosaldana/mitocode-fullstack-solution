import { GenericService } from './generic.service';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { Subject } from 'rxjs';
import { Signo } from './../_model/signo';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SignoService extends GenericService<Signo> {
  signoCambio = new Subject<Signo[]>();
  mensajeCambio = new Subject<string>();

  constructor(protected http: HttpClient) {
    super(http, `${environment.HOST}/signos`);
  }
}
