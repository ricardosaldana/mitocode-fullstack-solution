import { Injectable } from '@angular/core';
import { GenericService } from './generic.service';
import { environment } from './../../environments/environment';
import { Signo } from './../_model/signo';

@Injectable({
  providedIn: 'root',
})
export class SignoService extends GenericService<Signo> {
  constructor(protected http: HttpClient) {

    super(
      http,
      `${environment.HOST}/signos`
    );
  }
}
