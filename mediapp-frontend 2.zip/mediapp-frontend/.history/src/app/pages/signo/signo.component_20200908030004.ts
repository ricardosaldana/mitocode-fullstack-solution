import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Signo } from './../../_model/signo';
import { SignoService } from '../../_service/signo.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-signo',
  templateUrl: './signo.component.html',
  styleUrls: ['./signo.component.css'],
})
export class SignoComponent implements OnInit {
  cantidad = 0;
  displayedColumns = [
    'idSigno',
    'Paciente',
    'Fecha',
    'Temperatura',
    'Pulso',
    'Ritmo',
    'acciones',
  ];
  dataSource: MatTableDataSource<Signo>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private signoService: SignoService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.signoService.signoCambio.subscribe(
      (data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      (errorResponse) => {
        console.log(errorResponse);
      },
      () => {
        this.dataSource.filterPredicate = (data: Signo, filter: string) => {
          return data.paciente.nombres.toLocaleLowerCase().includes(filter);
        };
      }
    );

    this.signoService.mensajeCambio.subscribe((data) => {
      this.snackBar.open(data, 'Aviso', {
        duration: 2000,
      });
    });
    this.signoService.listar().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },
    (errorResponse) => {
      console.log(errorResponse);
    },
    () => {
      this.dataSource.filterPredicate = (data: Signo, filter: string) => {
        return data.paciente.nombres.toLocaleLowerCase().includes(filter);
      };
    });
  }

  filtrar(valor: string) {
    this.dataSource.filter = valor.trim().toLowerCase();
  }

  eliminar(signo: Signo) {
    this.signoService
      .eliminar(signo.idSigno)
      .pipe(
        switchMap(() => {
          return this.signoService.listar();
        })
      )
      .subscribe((data) => {
        this.signoService.signoCambio.next(data);
        this.signoService.mensajeCambio.next('Se eliminó');
      });
  }
}
