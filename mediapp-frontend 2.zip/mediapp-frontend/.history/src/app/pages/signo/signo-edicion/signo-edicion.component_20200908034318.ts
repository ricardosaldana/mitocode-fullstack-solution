import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { SignoService } from 'src/app/_service/signo.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Signo } from 'src/app/_model/signo';
import { switchMap, map } from 'rxjs/operators';
import { Paciente } from 'src/app/_model/paciente';
import { Observable } from 'rxjs';
import { PacienteService } from 'src/app/_service/paciente.service';
import * as moment from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signo-edicion',
  templateUrl: './signo-edicion.component.html',
  styleUrls: ['./signo-edicion.component.css'],
})
export class SignoEdicionComponent implements OnInit {
  id: number;
  signo: Signo;
  form: FormGroup;
  edicion = false;

  pacienteSeleccionado: Paciente;
  pacientes: Paciente[] = [];
  maxFecha: Date = new Date();
  fechaSeleccionada: Date = new Date();
  // utiles para autocomplete
  myControlPaciente: FormControl = new FormControl();
  pacientesFiltrados: Observable<Paciente[]>;

  constructor(
    private pacienteService: PacienteService,
    private signoService: SignoService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.signo = new Signo();

    this.form = new FormGroup({
      id: new FormControl(0),
      paciente: this.myControlPaciente,
      fechaSeleccionada: new FormControl(this.fechaSeleccionada),
      temperatura: new FormControl(''),
      pulso: new FormControl(''),
      ritmo: new FormControl(''),
    });

    this.listarPacientes();

    this.route.params.subscribe((params: Params) => {
      this.id = params.id;
      this.edicion = params.id != null;
      this.initForm();
    });

    this.pacientesFiltrados = this.myControlPaciente.valueChanges.pipe(
      map((val) => this.filtrarPacientes(val))
    );
  }

  filtrarPacientes(val: any) {
    if (val != null && val.idPaciente > 0) {
      return this.pacientes.filter(
        (el) =>
          el.nombres.toLowerCase().includes(val.nombres.toLowerCase()) ||
          el.apellidos.toLowerCase().includes(val.apellidos.toLowerCase()) ||
          el.dni.includes(val.dni)
      );
    }
    return this.pacientes.filter(
      (el) =>
        el.nombres.toLowerCase().includes(val?.toLowerCase()) ||
        el.apellidos.toLowerCase().includes(val?.toLowerCase()) ||
        el.dni.includes(val)
    );
  }
  initForm() {
    if (this.edicion) {
      this.signoService.listarPorId(this.id).subscribe((data) => {
        const id = data.idSigno;
        const paciente = data.paciente;
        const fecha = data.fecha;
        const temperatura = data.temperatura;
        const pulso = data.pulso;
        const ritmo = data.ritmo;

        this.form = new FormGroup({
          id: new FormControl(id),
          paciente: this.myControlPaciente,
          // paciente: new FormControl(paciente),
          fechaSeleccionada: new FormControl(fecha),
          temperatura: new FormControl(temperatura),
          pulso: new FormControl(pulso),
          ritmo: new FormControl(ritmo),
        });
        this.form.value.paciente = paciente;
      });
    }
  }

  operar() {
    this.signo.idSigno = this.form.value.id;
    this.signo.paciente = this.form.value.paciente;
    this.signo.fecha = moment(this.form.value.fechaSeleccionada).format('YYYY-MM-DDTHH:mm:ss');
    this.signo.temperatura = this.form.value.temperatura;
    this.signo.pulso = this.form.value.pulso;
    this.signo.ritmo = this.form.value.ritmo;
    if (this.signo != null && this.signo.idSigno > 0) {
      // BUENA PRACTICA
      this.signoService
        .modificar(this.signo)
        .pipe(
          switchMap(() => {
            return this.signoService.listar();
          })
        )
        .subscribe((data) => {
          this.signoService.signoCambio.next(data);
          this.signoService.mensajeCambio.next('Se modifico');
        });
    } else {
      // PRACTICA COMUN
      this.signoService.registrar(this.signo).subscribe((data) => {
        this.signoService.listar().subscribe((especialidad) => {
          this.signoService.signoCambio.next(especialidad);
          this.signoService.mensajeCambio.next('Se registro');
        });
      });
    }

    this.router.navigate(['signo']);
  }

  mostrarPaciente(val: Paciente) {
    return val ? `${val.nombres} ${val.apellidos}` : val;
  }

  seleccionarPaciente(e: any) {
    this.pacienteSeleccionado = e.option.value;
  }
  listarPacientes() {
    this.pacienteService.listar().subscribe((data) => {
      this.pacientes = data;
    });
  }

  cambieFecha(e: any) {
    console.log(e);
  }
}
