import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signo-edicion',
  templateUrl: './signo-edicion.component.html',
  styleUrls: ['./signo-edicion.component.css']
})
export class SignoEdicionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
