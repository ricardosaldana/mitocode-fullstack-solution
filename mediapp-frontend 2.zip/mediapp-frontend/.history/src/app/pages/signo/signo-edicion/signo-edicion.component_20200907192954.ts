import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { SignoService } from 'src/app/_service/signo.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Signo } from 'src/app/_model/signo';
import { switchMap } from 'rxjs/operators';
import { Paciente } from 'src/app/_model/paciente';

@Component({
  selector: 'app-signo-edicion',
  templateUrl: './signo-edicion.component.html',
  styleUrls: ['./signo-edicion.component.css']
})
export class SignoEdicionComponent implements OnInit {

  id: number;
  signo: Signo;
  form: FormGroup;
  edicion: boolean = false;
  pacienteSeleccionado: Paciente;

  // utiles para autocomplete
  myControlPaciente: FormControl = new FormControl();

  constructor(
    private signoService: SignoService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.signo = new Signo();

    this.form = new FormGroup({
      'id': new FormControl(0),
      'paciente': new FormControl(''),
      'fecha': new FormControl(''),
    });


    this.route.params.subscribe((params: Params) => {
      this.id = params['id'];

      this.edicion = params['id'] != null;
      this.initForm();
    });
  }

  initForm() {
    if (this.edicion) {
      this.signoService.listarPorId(this.id).subscribe(data => {
        let id = data.idSigno;
        let paciente = data.paciente;
        let fecha = data.fecha;

        this.form = new FormGroup({
          'id': new FormControl(id),
          'paciente': new FormControl(paciente),
          'fecha': new FormControl(fecha)
        });
      });
    }
  }

  operar() {
    this.signo.idSigno = this.form.value['idSigno'];
    this.signo.paciente = this.form.value['paciente'];
    this.signo.fecha = this.form.value['fecha'];

    if (this.signo != null && this.signo.idSigno > 0) {
      // BUENA PRACTICA
      this.signoService.modificar(this.signo).pipe(switchMap(() => {
        return this.signoService.listar();
      })).subscribe(data => {
        this.signoService.signoCambio.next(data);
        this.signoService.mensajeCambio.next('Se modifico');
      });
    } else {
      // PRACTICA COMUN
      this.signoService.registrar(this.signo).subscribe(data => {
        this.signoService.listar().subscribe(especialidad => {
          this.signoService.signoCambio.next(especialidad);
          this.signoService.mensajeCambio.next('Se registro');
        });
      });
    }

    this.router.navigate(['signo']);
  }

  mostrarPaciente(val: Paciente) {
    return val ? `${val.nombres} ${val.apellidos}` : val;
  }

  seleccionarPaciente(e: any) {
    this.pacienteSeleccionado = e.option.value;
  }

}
