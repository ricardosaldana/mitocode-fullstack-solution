import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signo',
  templateUrl: './signo.component.html',
  styleUrls: ['./signo.component.css']
})
export class SignoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
