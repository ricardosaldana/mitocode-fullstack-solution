export class Signo {
}
