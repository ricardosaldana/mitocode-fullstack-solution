export class Signo {
  idSigno: number;
}
