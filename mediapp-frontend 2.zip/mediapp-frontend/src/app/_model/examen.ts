export class Examen {
    idExamen: number;
    nombre: string;
    descripcion: string;
}