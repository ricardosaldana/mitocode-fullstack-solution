export class DetalleConsulta {
    diagnostico: string;
    tratamiento: string;
}