package com.mitocode.repo;

import com.mitocode.model.Archivo;

public interface IArchivoRepo extends IGenericRepo<Archivo, Integer>{

}
