package com.mitocode.repo;

import com.mitocode.model.Especialidad;

//@Respository
public interface IEspecialidadRepo extends IGenericRepo<Especialidad, Integer>{

}
