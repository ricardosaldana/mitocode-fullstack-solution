package com.mitocode.repo;

import com.mitocode.model.Paciente;

//@Respository
public interface IPacienteRepo extends IGenericRepo<Paciente, Integer>{

}
