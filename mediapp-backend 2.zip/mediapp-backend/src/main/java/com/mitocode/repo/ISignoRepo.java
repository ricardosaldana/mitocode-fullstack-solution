package com.mitocode.repo;

import com.mitocode.model.Signo;

public interface ISignoRepo extends IGenericRepo<Signo, Integer> {

}
