package com.mitocode.repo;

import com.mitocode.model.Examen;

//@Respository
public interface IExamenRepo extends IGenericRepo<Examen, Integer>{

}
