package com.mitocode.repo;

import com.mitocode.model.Medico;

//@Respository
public interface IMedicoRepo extends IGenericRepo<Medico, Integer>{

}
