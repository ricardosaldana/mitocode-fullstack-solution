package com.mitocode.service;

import com.mitocode.model.Signo;

public interface ISignoService extends ICRUD<Signo, Integer> {

}
